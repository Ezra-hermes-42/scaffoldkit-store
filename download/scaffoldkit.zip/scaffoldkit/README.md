# ScaffoldKit — Project Scaffolding CLI

**Stop wasting time on project setup. Generate complete, production-ready project structures in seconds.**

ScaffoldKit is a CLI tool that creates fully configured project directories with everything you need: Docker setup, CI/CD pipelines, linting config, test frameworks, and proper project structure — all from a single command.

## What You Get

| Language | Templates |
|----------|-----------|
| **Python** | main.py, requirements.txt, Makefile, Dockerfile, docker-compose, pytest setup, pylint, GitHub Actions CI, .gitignore, .editorconfig, LICENSE, README |
| **Node.js** | index.js, package.json, Dockerfile, docker-compose, Node test, ESLint, GitHub Actions CI, .gitignore, README |
| **Go** | main.go, go.mod, Dockerfile, docker-compose, Go test, GitHub Actions CI, .gitignore, README |

## Quick Start

```bash
# Install
pip install scaffoldkit

# Generate a Python project with everything
scaffoldkit python my-app --all

# Or a Node.js API
scaffoldkit node my-api --docker --ci --test

# Or a Go service
scaffoldkit go my-service --all

# cd in and start coding
cd my-app && make test
```

## Why ScaffoldKit?

- **Saves 15-30 minutes per project** — no more copy-pasting boilerplate
- **Production defaults** — Docker, CI, linting, testing all pre-configured
- **Consistent structure** — every project follows the same conventions
- **Free updates** — new stacks and templates added over time

## What's Included

Every generated project comes with:
- `.gitignore` — language-appropriate ignores
- `.editorconfig` — cross-editor consistency
- `LICENSE` — MIT by default, Apache/GPL options
- `README.md` — documentation template
- `Makefile` — common commands (install, test, lint, format)

Optional (use `--all` or individual flags):
- **Docker** — `Dockerfile` + `docker-compose.yml` for local dev
- **CI/CD** — GitHub Actions workflow with multi-version testing
- **Linting** — ESLint (Node), pylint (Python), go vet (Go)
- **Testing** — test framework with placeholder tests

## Requirements

- Python 3.8+
- Works on Linux, macOS, Windows (via WSL)

## Support

- Email: (coming soon)
- Issues: GitHub (coming soon)

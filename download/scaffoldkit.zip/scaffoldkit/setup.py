from setuptools import setup, find_packages

setup(
    name="scaffoldkit",
    version="1.0.0",
    description="CLI tool that scaffolds complete project setups in seconds",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "scaffoldkit=scaffoldkit.cli:main",
        ],
    },
    python_requires=">=3.8",
)

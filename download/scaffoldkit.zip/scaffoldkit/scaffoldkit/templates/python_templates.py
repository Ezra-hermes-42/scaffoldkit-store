"""Template strings for Python project scaffolding."""

PYTHON_DOCKERFILE = """# syntax=docker/dockerfile:1
FROM python:3.12-slim

WORKDIR /app

RUN apt-get update && apt-get install -y --no-install-recommends \\
    build-essential \\
    && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["python", "main.py"]
"""

PYTHON_DOCKER_COMPOSE = """version: '3.8'

services:
  app:
    build: .
    ports:
      - "8000:8000"
    volumes:
      - .:/app
    environment:
      - PYTHONUNBUFFERED=1
      - ENVIRONMENT=development
"""

PYTHON_GITIGNORE = """# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
.env
*.egg-info/
dist/
build/
*.egg
.venv

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Testing
.coverage
htmlcov/
.pytest_cache/
.tox/

# Docker
.docker/
"""

PYTHON_LINT = """[MASTER]
max-line-length=100
ignore=venv,.venv,.git,__pycache__

[MESSAGES CONTROL]
disable=C0114,C0115,C0116,R0903

[REPORTS]
output-format=colorized
"""

PYTHON_TEST_CONFIG = """[tool:pytest]
testpaths = tests
python_files = test_*.py
"""

PYTHON_REQUIREMENTS = """# Core
requests>=2.31.0
click>=8.1.0

# Dev
pytest>=7.0.0
pytest-cov>=4.0.0
black>=23.0.0
flake8>=6.0.0
"""

PYTHON_MAKEFILE = """.PHONY: install test lint clean docker

install:
\tpip install -r requirements.txt

test:
\tpytest

lint:
\tflake8 .
\tblack --check .

format:
\tblack .

clean:
\trm -rf __pycache__ .pytest_cache .coverage htmlcov

docker:
\tdocker-compose up --build

run:
\tpython main.py
"""

PYTHON_CI = """name: CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.10", "3.11", "3.12"]

    steps:
    - uses: actions/checkout@v4
    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v5
      with:
        python-version: ${{ matrix.python-version }}
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements.txt
    - name: Lint
      run: |
        pip install flake8 black
        flake8 .
        black --check .
    - name: Test
      run: |
        pip install pytest pytest-cov
        pytest --cov=./ --cov-report=xml
"""

LICENSES = {
    "mit": "MIT License\n\nCopyright (c) {year}\n\nPermission is hereby granted, free of charge...",
    "apache": "Apache License\nVersion 2.0, January 2004\nhttp://www.apache.org/licenses/",
    "gpl": "GNU GENERAL PUBLIC LICENSE\nVersion 3, 29 June 2007",
}

EDITORCONFIG = """root = true

[*]
indent_style = space
indent_size = 4
end_of_line = lf
charset = utf-8
trim_trailing_whitespace = true
insert_final_newline = true

[*.md]
trim_trailing_whitespace = false
"""

MAIN_PY = """def main():
    print("Hello from {name}!")


if __name__ == "__main__":
    main()
"""

TEST_PY = '''"""Placeholder tests — replace with real tests."""
import pytest


def test_placeholder():
    assert True
'''

README_PY = """# {name}

{description}

## Quick Start

```bash
# Install dependencies
make install

# Run
python main.py

# Test
make test
```

## Project Structure

```
.
├── main.py              # Entry point
├── requirements.txt     # Dependencies
├── Makefile             # Common commands
├── .editorconfig        # Editor settings
├── .github/
│   └── workflows/
│       └── ci.yml      # CI/CD pipeline
├── tests/
│   └── test_main.py    # Test suite
└── README.md           # This file
```

## License

{license}
"""

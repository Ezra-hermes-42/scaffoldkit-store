#!/usr/bin/env python3
"""ScaffoldKit — Project Scaffolding CLI. Generates complete project setups."""

import argparse
import os
import sys

from scaffoldkit.generators.python_gen import generate_python_project
from scaffoldkit.generators.node_gen import generate_node_project
from scaffoldkit.generators.go_gen import generate_go_project


def main():
    parser = argparse.ArgumentParser(
        description="ScaffoldKit — Generate complete project setups in seconds.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  scaffoldkit python my-project             # Python project
  scaffoldkit node my-api --framework express # Node.js Express API
  scaffoldkit go my-service                  # Go project
  scaffoldkit python my-api --docker         # Python + Docker
  scaffoldkit node my-app --all              # Full setup (Docker, CI, lint, test)
        """,
    )

    parser.add_argument("stack", choices=["python", "node", "go"],
                        help="Target language/stack")
    parser.add_argument("name", help="Project name")
    parser.add_argument("--path", "-p", default=".",
                        help="Output directory (default: current dir)")
    parser.add_argument("--docker", action="store_true",
                        help="Include Docker setup")
    parser.add_argument("--ci", action="store_true",
                        help="Include CI/CD config (GitHub Actions)")
    parser.add_argument("--lint", action="store_true",
                        help="Include linting config")
    parser.add_argument("--test", action="store_true",
                        help="Include test framework setup")
    parser.add_argument("--all", action="store_true",
                        help="Include all optional components")
    parser.add_argument("--license", choices=["mit", "apache", "gpl", "none"],
                        default="mit", help="License type (default: MIT)")
    parser.add_argument("--description", "-d", default="",
                        help="Project description")

    args = parser.parse_args()

    # Resolve flags
    docker = args.docker or args.all
    ci = args.ci or args.all
    lint = args.lint or args.all
    test = args.test or args.all

    project_dir = os.path.join(os.path.abspath(args.path), args.name)

    if os.path.exists(project_dir):
        print(f"❌ Error: Directory '{project_dir}' already exists.")
        sys.exit(1)

    generators = {
        "python": generate_python_project,
        "node": generate_node_project,
        "go": generate_go_project,
    }

    gen = generators[args.stack]
    gen(
        name=args.name,
        project_dir=project_dir,
        description=args.description,
        license_type=args.license,
        include_docker=docker,
        include_ci=ci,
        include_lint=lint,
        include_test=test,
    )

    print(f"\n✅ Project '{args.name}' scaffolded at: {project_dir}")
    print(f"   Stack: {args.stack}")
    print(f"   Components: Docker={docker} CI={ci} Lint={lint} Test={test}")
    print(f"   License: {args.license}")
    print()
    print(f"   cd {os.path.relpath(project_dir, os.path.abspath(args.path)) if args.path != '.' else args.name}")
    print(f"   ls")


if __name__ == "__main__":
    main()

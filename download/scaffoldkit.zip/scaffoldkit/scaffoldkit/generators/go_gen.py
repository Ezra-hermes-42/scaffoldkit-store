"""Go project generator."""
import os

GO_GITIGNORE = """# Binaries
*.exe
*.exe~
*.dll
*.so
*.dylib
{name}*
!{name}/

# Test
*.test
*.out
coverage.out
coverage.html

# IDE
.vscode/
.idea/

# OS
.DS_Store
Thumbs.db

# Env
.env
"""

GO_DOCKERFILE = """FROM golang:1.23-alpine AS builder

WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 go build -o /app/server .

FROM alpine:3.19
RUN apk --no-cache add ca-certificates
WORKDIR /root/
COPY --from=builder /app/server .
EXPOSE 8080
CMD ["./server"]
"""

GO_DOCKER_COMPOSE = """version: '3.8'

services:
  app:
    build: .
    ports:
      - "8080:8080"
    volumes:
      - .:/app
    environment:
      - GO_ENV=development
"""

GO_CI = """name: CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    - name: Set up Go
      uses: actions/setup-go@v5
      with:
        go-version: "1.23"
    - name: Lint
      run: |
        go vet ./...
    - name: Test
      run: go test -v -race -coverprofile=coverage.out ./...
    - name: Build
      run: go build -o /dev/null ./...
"""

GO_MAIN = """package main

import (
\t"fmt"
\t"log"
\t"net/http"
\t"os"
)

func main() {
\tport := os.Getenv("PORT")
\tif port == "" {
\t\tport = "8080"
\t}

\thttp.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
\t\tfmt.Fprintf(w, "Hello from %s!\\n", "{name}")
\t})

\tlog.Printf("Server starting on :%s", port)
\tlog.Fatal(http.ListenAndServe(":"+port, nil))
}
"""

GO_TEST = """package main

import (
\t"net/http"
\t"net/http/httptest"
\t"testing"
)

func TestHelloHandler(t *testing.T) {
\treq := httptest.NewRequest(http.MethodGet, "/", nil)
\trec := httptest.NewRecorder()

\thttp.DefaultServeMux.ServeHTTP(rec, req)

\tif rec.Code != http.StatusOK {
\t\tt.Errorf("expected 200, got %d", rec.Code)
\t}
}
"""

GO_MOD = """module {module_path}

go 1.23
"""

GO_README = """# {name}

{description}

## Quick Start

```bash
go run .
```

## Build

```bash
go build -o {name} .
./{name}
```

## Test

```bash
go test -v ./...
```

## License

{license}
"""


def write_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(content)
    print(f"  Created: {os.path.relpath(path)}")


def generate_go_project(name, project_dir, description="",
                        license_type="mit", include_docker=False,
                        include_ci=False, include_lint=False,
                        include_test=False):
    os.makedirs(project_dir, exist_ok=True)

    license_map = {"mit": "MIT", "apache": "Apache-2.0", "gpl": "GPL-3.0"}

    write_file(os.path.join(project_dir, "main.go"),
               GO_MAIN.replace("{name}", name))
    write_file(os.path.join(project_dir, "go.mod"),
               GO_MOD.format(module_path=name))
    write_file(os.path.join(project_dir, ".gitignore"),
               GO_GITIGNORE.format(name=name))
    write_file(os.path.join(project_dir, ".editorconfig"),
               GO_EDITORCONFIG)

    if include_docker:
        write_file(os.path.join(project_dir, "Dockerfile"), GO_DOCKERFILE)
        write_file(os.path.join(project_dir, "docker-compose.yml"),
                   GO_DOCKER_COMPOSE)

    if include_ci:
        ci_dir = os.path.join(project_dir, ".github", "workflows")
        write_file(os.path.join(ci_dir, "ci.yml"), GO_CI)

    if include_test:
        write_file(os.path.join(project_dir, "main_test.go"),
                   GO_TEST)

    write_file(os.path.join(project_dir, "README.md"),
               GO_README.format(name=name, description=description,
                                license=license_map.get(license_type, "MIT")))

    return project_dir


GO_EDITORCONFIG = """root = true

[*]
indent_style = tab
indent_size = 4
end_of_line = lf
charset = utf-8
trim_trailing_whitespace = true
insert_final_newline = true

[*.md]
indent_style = space
indent_size = 2
trim_trailing_whitespace = false
"""

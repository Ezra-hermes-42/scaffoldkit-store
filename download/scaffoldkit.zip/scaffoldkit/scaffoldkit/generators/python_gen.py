"""Python project generator."""
import os

from scaffoldkit.templates.python_templates import (
    PYTHON_DOCKERFILE, PYTHON_DOCKER_COMPOSE, PYTHON_GITIGNORE,
    PYTHON_LINT, PYTHON_TEST_CONFIG, PYTHON_REQUIREMENTS,
    PYTHON_MAKEFILE, PYTHON_CI, EDITORCONFIG, MAIN_PY, TEST_PY,
    README_PY, LICENSES,
)


def write_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(content)
    print(f"  Created: {os.path.relpath(path)}")


def generate_python_project(name, project_dir, description="",
                            license_type="mit", include_docker=False,
                            include_ci=False, include_lint=False,
                            include_test=False):
    os.makedirs(project_dir, exist_ok=True)

    # Collect what we'll generate (for the readme)
    features = []

    # Always create
    write_file(os.path.join(project_dir, "main.py"),
               MAIN_PY.format(name=name))
    write_file(os.path.join(project_dir, "requirements.txt"),
               PYTHON_REQUIREMENTS)
    write_file(os.path.join(project_dir, "Makefile"), PYTHON_MAKEFILE)
    write_file(os.path.join(project_dir, ".gitignore"), PYTHON_GITIGNORE)
    write_file(os.path.join(project_dir, ".editorconfig"), EDITORCONFIG)

    # License
    license_text = LICENSES.get(license_type, LICENSES["mit"])
    write_file(os.path.join(project_dir, "LICENSE"), license_text)

    # Docker
    if include_docker:
        write_file(os.path.join(project_dir, "Dockerfile"), PYTHON_DOCKERFILE)
        write_file(os.path.join(project_dir, "docker-compose.yml"),
                   PYTHON_DOCKER_COMPOSE)
        features.append("Docker")

    # CI
    if include_ci:
        ci_dir = os.path.join(project_dir, ".github", "workflows")
        write_file(os.path.join(ci_dir, "ci.yml"), PYTHON_CI)
        features.append("CI/CD")

    # Lint
    if include_lint:
        write_file(os.path.join(project_dir, ".pylintrc"), PYTHON_LINT)
        features.append("Linting")

    # Test
    if include_test:
        tests_dir = os.path.join(project_dir, "tests")
        write_file(os.path.join(tests_dir, "__init__.py"), "")
        write_file(os.path.join(tests_dir, "test_main.py"), TEST_PY)
        write_file(os.path.join(project_dir, "setup.cfg"), PYTHON_TEST_CONFIG)
        features.append("Testing")

    # README
    dev_section = ""
    if include_docker:
        dev_section += "### Docker\n\n```bash\ndocker-compose up --build\n```\n\n"
    if include_test:
        dev_section += "### Testing\n\n```bash\nmake test\n```\n\n"
    if not dev_section:
        dev_section = "Edit `main.py` to get started."

    readme = README_PY.format(
        name=name,
        description=description or f"A Python project by {name}",
        license=license_text.split("\n")[0],
    )
    write_file(os.path.join(project_dir, "README.md"), readme)

    return project_dir

"""Node.js project generator."""
import os

NODE_GITIGNORE = """node_modules/
.env
.env.local
dist/
build/
*.log
.DS_Store
coverage/
.vscode/
.idea/
"""

NODE_DOCKERFILE = """FROM node:22-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

EXPOSE 3000

CMD ["node", "index.js"]
"""

NODE_DOCKER_COMPOSE = """version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    volumes:
      - .:/app
      - /app/node_modules
    environment:
      - NODE_ENV=development
"""

NODE_PACKAGE_JSON = """{
  "name": "{name}",
  "version": "1.0.0",
  "description": "{description}",
  "main": "index.js",
  "scripts": {
    "start": "node index.js",
    "dev": "node --watch index.js",
    "test": "node --test tests/",
    "lint": "eslint ."
  },
  "keywords": [],
  "license": "{license}"
}
"""

NODE_CI = """name: CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        node-version: ["18", "20", "22"]

    steps:
    - uses: actions/checkout@v4
    - name: Use Node.js ${{ matrix.node-version }}
      uses: actions/setup-node@v4
      with:
        node-version: ${{ matrix.node-version }}
    - run: npm ci
    - run: npm test
"""

NODE_ESLINT = """{
  "env": { "node": true, "es2022": true },
  "extends": "eslint:recommended",
  "parserOptions": { "ecmaVersion": "latest" },
  "rules": {
    "no-unused-vars": "warn",
    "no-console": "off"
  }
}
"""

NODE_INDEX = """const http = require('http');

const host = process.env.HOST || '0.0.0.0';
const port = process.env.PORT || 3000;

const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello from {name}!\\n');
});

server.listen(port, host, () => {
  console.log(`Server running at http://${host}:${port}/`);
});
"""

NODE_TEST = """const assert = require('assert/strict');
const { describe, it } = require('node:test');

describe('{name}', () => {
  it('should work', () => {
    assert.equal(1 + 1, 2);
  });
});
"""

NODE_README = """# {name}

{description}

## Quick Start

```bash
npm install
npm start
```

## Development

```bash
npm run dev    # Run with auto-reload
npm test       # Run tests
npm run lint   # Lint code
```

## License

{license}
"""


def write_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(content)
    print(f"  Created: {os.path.relpath(path)}")


def generate_node_project(name, project_dir, description="",
                          license_type="mit", include_docker=False,
                          include_ci=False, include_lint=False,
                          include_test=False):
    os.makedirs(project_dir, exist_ok=True)

    license_map = {"mit": "MIT", "apache": "Apache-2.0", "gpl": "GPL-3.0"}

    write_file(os.path.join(project_dir, "index.js"),
               NODE_INDEX.replace("{name}", name))
    write_file(os.path.join(project_dir, "package.json"),
               NODE_PACKAGE_JSON
               .replace("{name}", name)
               .replace("{description}", description)
               .replace("{license}", license_map.get(license_type, "MIT")))
    write_file(os.path.join(project_dir, ".gitignore"), NODE_GITIGNORE)
    write_file(os.path.join(project_dir, ".editorconfig"), EDITORCONFIG)

    if include_docker:
        write_file(os.path.join(project_dir, "Dockerfile"), NODE_DOCKERFILE)
        write_file(os.path.join(project_dir, "docker-compose.yml"),
                   NODE_DOCKER_COMPOSE)

    if include_ci:
        ci_dir = os.path.join(project_dir, ".github", "workflows")
        write_file(os.path.join(ci_dir, "ci.yml"), NODE_CI)

    if include_lint:
        write_file(os.path.join(project_dir, ".eslintrc.json"), NODE_ESLINT)

    if include_test:
        tests_dir = os.path.join(project_dir, "tests")
        write_file(os.path.join(tests_dir, "test_main.js"),
                   NODE_TEST.replace("{name}", name))

    write_file(os.path.join(project_dir, "README.md"),
               NODE_README
               .replace("{name}", name)
               .replace("{description}", description)
               .replace("{license}", license_map.get(license_type, "MIT")))

    return project_dir


EDITORCONFIG = """root = true

[*]
indent_style = space
indent_size = 2
end_of_line = lf
charset = utf-8
trim_trailing_whitespace = true
insert_final_newline = true

[*.md]
trim_trailing_whitespace = false
"""
